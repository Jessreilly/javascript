# Falling Letters

A Pen created on CodePen.io. Original URL: [https://codepen.io/danwilson/pen/wWZWKW](https://codepen.io/danwilson/pen/wWZWKW).

I remember playing a game on the Commodore 64 with letters that fell and you had to press the corresponding key before it reached the ground.  I think there was a parachute in some capacity, as well. 
Either way, this is my attempt at recreating what I remember of this game... using the Web Animations API.
Need a keyboard for now... plan to add a gesture mode as well (arrows instead of letters)